package Session4_Assignment1;
import java.util.Scanner;
public class acad5 {
	public void multiplier(int a)
	{
		for (int i=1; i<=10; i++)
		{
			int b = a*i;
			System.out.println(a + "x" +i + " = " +b);
		}
	}
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner number1 = new Scanner(System.in);
		System.out.println("Enter a Number: ");
		int a = number1.nextInt();
		acad5 findmultipliers = new acad5();
		findmultipliers.multiplier(a);
	}
}
