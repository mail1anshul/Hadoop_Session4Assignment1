package Session4_Assignment1;
import java.util.Scanner;
public class acad4 {
		public void OddEven(int a, int b)
	{
			System.out.println("Below are odd and even numbers between first and second numbers" );
			for (int i=a+1; i<b; i++)
		{
			if ((i%2)==0)
			{
				System.out.println("Number " + i + " is even" );
			}
			else
			{
				System.out.println("Number " + i + " is odd" );
			}
		}
	}
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner UserInput1 = new Scanner(System.in);
		System.out.println("First number is: ");
		int a = UserInput1.nextInt();
		Scanner UserInput2 = new Scanner(System.in);
		System.out.println("Second number is: ");
		int b = UserInput2.nextInt();
		acad4 findoddeven = new acad4();
		findoddeven.OddEven(a, b);
	}
}
