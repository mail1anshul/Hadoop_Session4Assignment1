package Session4_Assignment1;

import java.util.Scanner;

public class acad3 {
	
	public void sum(int a, int b)
	{
		int c = a+b;
		System.out.println("Sum is: " + c);		
	}

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner UserInput1 = new Scanner(System.in);
		System.out.println("First number is: ");
		int a = UserInput1.nextInt();
		Scanner UserInput2 = new Scanner(System.in);
		System.out.println("Second number is: ");
		int b = UserInput2.nextInt();
		acad3 d = new acad3();
		d.sum(a, b);
	}
}
