package Session4_Assignment1;
import java.util.Scanner;
public class acad8 {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner totalelements = new Scanner(System.in);
        System.out.print("Enter no. of elements in array:");
        int elements = totalelements.nextInt();
        int a[] = new int[elements];
        System.out.println("Enter all elements:");
        for (int i = 0; i < elements; i++) 
        {
            a[i] = totalelements.nextInt();
        }
        for (int i = 0; i < elements; i++) 
        {
            for (int j = i + 1; j < elements; j++) 
            {
                if (a[i] < a[j]) 
                {
                    int temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
        }
        System.out.print("Descending Order of numbers is:");
        for (int i = 0; i < elements - 1; i++) 
        {
            System.out.print(a[i] + ",");
        }
        System.out.print(a[elements - 1]);
	}
}
