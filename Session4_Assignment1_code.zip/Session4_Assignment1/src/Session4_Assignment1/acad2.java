package Session4_Assignment1;

import java.util.Scanner;

public class acad2 {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner UserInput1 = new Scanner(System.in);
		System.out.println("Enter First Number: ");
		int a = UserInput1.nextInt();
		Scanner UserInput2 = new Scanner(System.in);
		System.out.println("Enter Second Number: ");
		int b = UserInput2.nextInt();
		int c=a+b;
	    System.out.println("Sum = " + c);
		
	}

}
