package Session4_Assignment1;

public class acad {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 10;
		int b = 15;
		int c = a+b;
		System.out.println("Sum = "  + c);
	}

}
