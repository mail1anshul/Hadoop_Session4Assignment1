package Session4_Assignment1;

import java.util.Scanner;

public class acad7 {
	
	public static int sum(int a, int b)
	{
		int c = a+b;
		return c;	
	}
	public static int sum(int a, int b, int c)
	{
		int d = a+b+c;
		return d;	
	}
		@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner UserInput1 = new Scanner(System.in);
		System.out.println("First number is: ");
		int a = UserInput1.nextInt();
		Scanner UserInput2 = new Scanner(System.in);
		System.out.println("Second number is: ");
		int b = UserInput2.nextInt();
		Scanner UserInput3 = new Scanner(System.in);
		System.out.println("Third number is: ");
		int c = UserInput3.nextInt();
		int d = sum(a, b);
		int e = sum(a, b, c);
		System.out.println("Sum of first 2 numbers is = " + d);
		System.out.println("Sum of all 3 numbers is = " + e);
	}
}
