package Session4_Assignment1;

import java.util.Scanner;

public class acad6 {
	
	public void sum(int a, int b)
	{
		int c = a+b;
		System.out.println("Sum of first 2 numbers is: " + c);		
	}
	public void sum(int a, int b, int c)
	{
		int d = a+b+c;
		System.out.println("Sum of all 3 numbers is: " + d);		
	}
		@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner UserInput1 = new Scanner(System.in);
		System.out.println("First number is: ");
		int a = UserInput1.nextInt();
		Scanner UserInput2 = new Scanner(System.in);
		System.out.println("Second number is: ");
		int b = UserInput2.nextInt();
		Scanner UserInput3 = new Scanner(System.in);
		System.out.println("Third number is: ");
		int c = UserInput3.nextInt();
		acad6 d = new acad6();
		d.sum(a, b);
		d.sum(a, b, c);
	}
}
